// Daniel Ladrón de Guevara
// 30 03 22
$(() => {
    // costruir tabla components

    let components = [
        { name: "Exposed walls" },
        { name: "Floor Area" },
        { name: "Exposed ceilings (W/ Attic)" },
        { name: "Exposed ceilings (W/O Attic)" },
        { name: "Exposed floors" },
        { name: "North shaded" },
        { name: "East/West" },
        { name: "South" },
        { name: "Skylight" },
        { name: "Doors" },
        {
            name: "Heat gain people",
            noHL: true
        },
        {
            name: "Appliance loads",
            measurementPercent: true,
            measurementStep: 25,
            hlReadonly: true
        },
        {
            name: "Duct loss",
            measurementPercent: true,
            measurementStep: 10,
        },
        {
            name: "Foundation conductive heatloss",
            noMeasurement: true,
            noHG: true
        },
        {
            name: "Total conductive",
            noMeasurement: true
        },
        {
            name: "Air Leakage",
            noMeasurement: true
        },
        {
            name: "Ventilation",
            noMeasurement: true
        }
    ]

    let componentsDiv = $("#properties-components")
    let propertiesContainer = componentsDiv.find("#components-container")
    components.forEach(component => {
        let id = component.name.replace(/[\W_]+/g, "") + "-component"
        let template = componentsDiv.find("#component-template").clone()
        template.prop("id", id)
        template.find(".component-cell").html(component.name)
        if (component.noHL) {
            template.find(".hl").addClass("d-none")
        }
        if (component.noHG) {
            template.find(".hg").addClass("d-none")
        }
        if (component.measurementPercent) {
            template.find(".measurement").parent().append(`
                <div class="input-group-prepend">
                    <span class="input-group-text">%</span>
                </div>
            `)
            template.find(".measurement").prop("max", "100")
        }
        if (component.measurementStep) {
            template.find(".measurement").prop("step", component.measurementStep)
        }
        if (component.hlReadonly) {
            template.find(".hl").removeClass("form-control")
            template.find(".hl").addClass("form-control-plaintext")
            template.find(".hl").attr("disabled", false)
            template.find(".hl").attr("readonly", true)
        }
        if (component.noMeasurement) {
            template.find(".measurement").addClass("d-none")
        }
        template.removeClass("d-none")
        propertiesContainer.append(template)
    })
    // añadir select systema al final de los components
    propertiesContainer.append($("#component-system").removeClass("d-none"))

    //construir tabla local r-values
    let r_values = [
        "North",
        "East/West",
        "South",
        "Skylight",
        "Doors",
        "Exposed Walls",
        "Exposed Ceilings W/ Attic",
        "Exposed Ceilings W/O Attic",
        "Exposed floors"
    ]

    let rValuesDiv = $("#properties-r-values")
    let rValuesContainer = $("#r-values-container")

    r_values.forEach(r_value => {
        let id = r_value.replace(/[\W_]+/g, "") + "-r-value"
        let template = rValuesDiv.find("#r-value-template").clone(true, true)
        template.prop("id", id)
        template.find(".r-value-name-cell").html(r_value)
        template.removeClass("d-none")
        rValuesContainer.append(template)
    })
})

// Manejo del evento change en select de la columna Use package values de la tabla de local r-values
// para activar la edición de los campos R-Value, Ex.Eff. R-Value y Ex. measure.
// falta manejo de formulas y cuando se seleccione el checkbox cargar los valores por defecto
$(".modal").on("change", ".is-package-value", (e) => {
    let checkbox = $(e.target)
    let row = checkbox.closest(".r-values-table")
    let rValue = row.find(".r-value")
    let exEffRValue = row.find(".ex-eff-r-value")
    let exMeasurement = row.find(".ex-measurement")

    let disabled = checkbox.is(':checked')

    rValue.attr("disabled", disabled)
    exEffRValue.attr("disabled", disabled)
    exMeasurement.attr("disabled", disabled)
})

$(".modal").on("change keyup input", "input", calcProperties)

function calcProperties() {

    calcRValues()

    // level 1
    let isBasementExisting = $("#isBasementExisting").is(':checked')
    let isBasementRadio = $("#isBasement").is(':checked') // false = Slab On Grade

    // no level 1
    let isExistingAirLeakage = $("#isExistingAirLeakage").is(':checked')
    let isSlabOnGrade = $("#isSlabOnGrade").is(':checked')

    // common
    let level = $("#room-level").text()
    //let actualName = $("#actualName")
    let height = $("#height")
    let aboveGrade = $("#aboveGrade")
    let belowGrade = $("#belowGrade")

    if (level == "Level 1" && isBasementRadio) {
        belowGrade.val(height.val() - aboveGrade.val())
    } else {
        aboveGrade.val(height.val())
        belowGrade.val("0")
    }

    let components = [
        $("#Exposedwalls-component"),
        $("#FloorArea-component"),
        $("#ExposedceilingsWAttic-component"),
        $("#ExposedceilingsWOAttic-component"),
        $("#Exposedfloors-component"),
        $("#Northshaded-component"),
        $("#EastWest-component"),
        $("#South-component"),
        $("#Skylight-component"),
        $("#Doors-component"),
        $("#Heatgainpeople-component"),
        $("#Applianceloads-component"),
        $("#Ductloss-component"),
        $("#Foundationconductiveheatloss-component"),
        $("#Totalconductive-component"),
        $("#AirLeakage-component"),
        $("#Ventilation-component"),
        $("#component-system")
    ];

    [
        $("#Northshaded-component"),
        $("#EastWest-component"),
        $("#South-component"),
        $("#Skylight-component"),
        $("#Doors-component")
    ].forEach((component) => { // calcular heatgain heatloss
        let measurementInput = component.find(".measurement")
        let heatlossInput = component.find(".hl")
        let heatgainInput = component.find(".hg")

    })

}

function calcRValues() {

    // objeto temporal sistema (investigar origen de estas variables)
    let sistema = {
        DTHeatloss: 72,
        odtHTG: -9.40,
        odtCool: 86,
        DTHeatgain: 72,
        windowThermalCalc1: 0.49,
        windowThermalCalc2: 29,
        windowThermalCalc3: 0.55,
        windowThermalCalc6: 169,
        windowThermalCalc7: 1,
        constRSI: 0.1761
    }

    // declarar r-values containers
    let north = $("#North-r-value")
    let eastWest = $("#EastWest-r-value")
    let south = $("#South-r-value")
    let skylight = $("#Skylight-r-value")
    let doors = $("#Doors-r-value")
    let exposedWalls = $("#ExposedWalls-r-value")
    let ceilingsWAttic = $("#ExposedCeilingsWAttic-r-value")
    let ceilingsWOAttic = $("#ExposedCeilingsWOAttic-r-value")
    let exposedfloors = $("#Exposedfloors-r-value");

    let allContainers = [
        north,
        eastWest,
        south,
        skylight,
        doors,
        exposedWalls,
        ceilingsWAttic,
        ceilingsWOAttic,
        exposedfloors
    ]

    // copiar el valor de r-value a effective r-value 5921
    allContainers.forEach(container => {
        let effRValueInput = container.find(".eff-r-value")
        let rValue = getRValue(container)

        effRValueInput.val(rValue)
    })

    let DTHeatloss = sistema.DTHeatloss - sistema.odtHTG
    let DTHeatgain = sistema.odtCool - sistema.DTHeatgain;

    // calcular heatloss :5755
    [
        north, eastWest, south, skylight, doors, exposedWalls, ceilingsWAttic, exposedfloors // falta ceilingsWOAttic
    ].forEach(container => {
        setHeatLoss(container, (DTHeatloss / getRValue(container)))
    });

    // calcular heatgain :5778
    [
        exposedWalls, doors
    ].forEach(container => {
        setHeatGain(container, (DTHeatgain / getRValue(container)))
    });

    [
        north, eastWest, south
    ].forEach(container => {
        setHeatGain(container,
            (DTHeatgain / getRValue(container)) +
            (sistema.windowThermalCalc1 * sistema.windowThermalCalc2 * sistema.windowThermalCalc3)
        )
    });

    setHeatGain(skylight,
        (DTHeatgain / getRValue(skylight))
        + (sistema.windowThermalCalc1 * sistema.windowThermalCalc6 * sistema.windowThermalCalc7)
    );

    [
        ceilingsWAttic, ceilingsWOAttic
    ].forEach(container => {
        setHeatGain(container,
            (DTHeatgain + 27) / getRValue(container)
        )
    });

    setHeatGain(exposedfloors, 
        (DTHeatgain - 6) / getRValue(exposedfloors)
    )


    // calcular rsi :5793
    allContainers.forEach(container => {
        setRSI(container, getRValue(container) * sistema.constRSI)
    })



}

function setHeatLoss(rValueContainer, value) {
    rValueContainer.find(".heatloss").val(value)
}

function setHeatGain(rValueContainer, value) {
    rValueContainer.find(".heatgain").val(value)
}

function getRValue(rValueContainer) {
    return rValueContainer.find(".r-value").val()
}

function setRSI(rValueContainer, value) {
    rValueContainer.find(".rsi").val(value)
}
