$(function() {
  function removeNote() {
      $(".remove-note").off('click').on('click', function(event) {
        event.stopPropagation();
        $(this).parents('.single-note-item').remove();
      })
  }

  // Daniel Ladrón de Guevara
  // 31 03 22 Funcion para manejar el evento de click en icono de propiedades
  // modifica el modal y lo muestra
  function propertiesNote() {
    $(".properties-note").off('click').on('click', function(event) {
      event.stopPropagation();
      let note = $(this).closest(".single-note-item")
      let modal = $("#modal-properties")

      // cargar color de habitación
      let color = note.find(".card-body").css("background-color")
      modal.find(".modal-header").css("background-color", color)

      // cargar icono de habitación a modal
      let icon = note.find(".note-title").children("img").clone()
      icon.prop("style", "width:30px;")
      modal.find("#modal-icon").empty().append(icon) // importante empty() antes para quitar el anterior

      // cargar nivel al modal
      let level = note.find(".note-date").html()
      modal.find("#room-level").html(level)

      // si el nivel de la habitación es 1
      //     - mostrar opciones de basement en el modal 
      //     - activar input Above grade
      if (level === "Level 1") {
        modal.find(".level-1").removeClass("d-none")
        modal.find(".no-level-1").addClass("d-none")
        modal.find("#aboveGrade").prop("disabled", false)
      } else {
        modal.find(".level-1").addClass("d-none")
        modal.find(".no-level-1").removeClass("d-none")
        modal.find("#aboveGrade").prop("disabled", true)
      }
      
      // aqui hacer petición asíncrona para pedir los datos del cuarto y modificar los inputs del modal
      modal.modal({
        backdrop: "static",
        keyboard: false
      })
    })
    
}

  function favouriteNote() {
      $(".favourite-note").off('click').on('click', function(event) {
        event.stopPropagation();
        $(this).parents('.single-note-item').toggleClass('note-favourite');
      })
  }

  function addLabelGroups() {
      $('.category-selector .badge-group-item').off('click').on('click', function(event) {
        event.preventDefault();
        /* Act on the event */
        var getclass = this.className;
        var getSplitclass = getclass.split(' ')[0];
        if ($(this).hasClass('level1')) { //Bussines LEVEL 1
          $(this).parents('.single-note-item').removeClass('level2');
          $(this).parents('.single-note-item').removeClass('level3');
          $(this).parents('.single-note-item').removeClass('level4');
          $(this).parents('.single-note-item').toggleClass(getSplitclass);
        } else if ($(this).hasClass('level2')) { //Social L2
          $(this).parents('.single-note-item').removeClass('level1');
          $(this).parents('.single-note-item').removeClass('level3');
          $(this).parents('.single-note-item').removeClass('level4');
          $(this).parents('.single-note-item').toggleClass(getSplitclass);
        } else if ($(this).hasClass('level3')) { //Important L3
          $(this).parents('.single-note-item').removeClass('level2');
          $(this).parents('.single-note-item').removeClass('level1');
          $(this).parents('.single-note-item').removeClass('level4');
          $(this).parents('.single-note-item').toggleClass(getSplitclass);
        } else if ($(this).hasClass('level4')) { //Important2 L4
            $(this).parents('.single-note-item').removeClass('level3');
            $(this).parents('.single-note-item').removeClass('level1');
            $(this).parents('.single-note-item').removeClass('level2');
            $(this).parents('.single-note-item').toggleClass(getSplitclass);
        }
      });
  }

  var $btns = $('.note-link').click(function() {
      if (this.id == 'all-category') {
        var $el = $('.' + this.id).fadeIn();
        $('#note-full-container > div').not($el).hide();
      } if (this.id == 'important') {
        var $el = $('.' + this.id).fadeIn();
        $('#note-full-container > div').not($el).hide();
      } else {
        var $el = $('.' + this.id).fadeIn();
        $('#note-full-container > div').not($el).hide();
      }
      $btns.removeClass('active');
      $(this).addClass('active');  
  })

  // Add Master Bedroom
  $('#add-mb').on('click', function(event) {
      $('#addmasterbedroom').modal('show');
      $('#btn-n-save').hide();
      $('#btn-n-add-mb').show();
  })

  // Add Room
  $('#add-ro').on('click', function(event) {
      $('#addroom').modal('show');
      $('#btn-n-save').hide();
      $('#btn-n-add-ro').show();
  })

  // Add Living
  $('#add-lv').on('click', function(event) {
      $('#addliving').modal('show');
      $('#btn-n-save').hide();
      $('#btn-n-add-lv').show();
  })

  // Add Kitchen
  $('#add-ki').on('click', function(event) {
    $('#addkitchen').modal('show');
    $('#btn-n-save').hide();
    $('#btn-n-add-kit').show();
  })

  // Add Bathroom
  $('#add-bth').on('click', function(event) {
    $('#addbathroom').modal('show');
    $('#btn-n-save').hide();
    $('#btn-n-add-bath').show();
  })

  // Add Utility Room
  $('#add-ur').on('click', function(event) {
    $('#addutilityroom').modal('show');
    $('#btn-n-save').hide();
    $('#btn-n-add-utr').show();
  })

  // Add Laundry Room
  $('#add-lr').on('click', function(event) {
    $('#addlaundryroom').modal('show');
    $('#btn-n-save').hide();
    $('#btn-n-add-lar').show();
  })

  // Button add Master Bedroom
  $("#btn-n-add-mb").on('click', function(event) {
      event.preventDefault();
      var $_level =  $( "#mbLevel" ).val();
      var $_levelLow = $_level.toLowerCase();
      var $_levelTrim = $_levelLow.replace(/\s+/g, '');
      $html =     '<div class="col-md-3 single-note-item all-category '+$_levelTrim+'"><div class="card card-body" style="background-color:#d84d38;">' +
                              '<span class="side-stick"></span>' +
                              '<h4 class="note-title text-truncate w-75 mb-0" data-noteHeading="" style="color:white;"><img src="dist/img/iconsmenu/Master.png" alt="" style="width:3em;"> Master Bedroom</h4>' +
                              '<div class="note-content" style="display:inline-flex;text-align:center;margin-top: 20px;font-size: 20px">' +
                                  '<p style="color:red">RED</p>' +
                                  '<p style="margin-left:10px; color:blue;">BLUE</p>' +
                              '</div>' +
                              '<p class="note-date" style="color:white;font-size: 20px;">'+$_level+'</p>' +
                              '<div class="d-flex align-items-center">' +
                                  '<span class="mr-3"><i class="fa fa-trash remove-note"></i> Remove</span>' +
                                  '<span class="mr-1"><i class="fa fa-wrench properties-note"></i> Properties</span>' +

                                //   '<div class="ml-auto">' +
                                //         '<div class="category-selector btn-group">' +
                                //                   '<a class="nav-link dropdown-toggle category-dropdown label-group p-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="true">' +
                                //                       '<div class="category">' +
                                //                           '<div class="category-l1"></div>' +
                                //                           '<div class="category-l2"></div>' +
                                //                           '<div class="category-l3"></div>' +
                                //                           '<div class="category-l4"></div>' +
                                //                           '<span class="more-options text-dark"><i class="icon-options-vertical"></i></span>'+
                                //                       '</div>' +
                                //                   '</a>' +
                                //                   '<div class="dropdown-menu dropdown-menu-right category-menu">' +
                                //                       '<a class="level1 badge-group-item badge-business dropdown-item position-relative category-l1" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 1</a>' +
                                //                       '<a class="level2 badge-group-item badge-social dropdown-item position-relative category-l2" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 2</a>' +
                                //                       '<a class="level3 badge-group-item badge-important dropdown-item position-relative category-l3" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 3</a>' +
                                //                       '<a class="level4 badge-group-item badge-important dropdown-item position-relative category-l4" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 4</a>' +
                                //               '</div>' +
                                //         '</div>' +
                                //   '</div>' +
                              '</div>' +
                          '</div></div> ';

      $("#note-full-container").prepend($html);
      $('#addmasterbedroom').modal('hide');

      removeNote();
      propertiesNote();
      favouriteNote();
      addLabelGroups();
      $(".remove-note, .properties-note").css('cursor', 'pointer');
  });

  // Button add Room
  $("#btn-n-add-ro").on('click', function(event) {
      event.preventDefault();
      var $_level =  $( "#roomLevel" ).val();
      var $_levelLow = $_level.toLowerCase();
      var $_levelTrim = $_levelLow.replace(/\s+/g, '');
      $html =     '<div class="col-md-3 single-note-item all-category '+$_levelTrim+'"><div class="card card-body" style="background-color:#d84d38;">' +
                              '<span class="side-stick"></span>' +
                              '<h4 class="note-title text-truncate w-75 mb-0" data-noteHeading="" style="color:white;"><img src="dist/img/iconsmenu/Room.png" alt="" style="width:3em;"> Room</h4>' +
                              '<div class="note-content" style="display:inline-flex;text-align:center;margin-top: 20px;font-size: 20px">' +
                                  '<p style="color:red">RED</p>' +
                                  '<p style="margin-left:10px; color:blue;">BLUE</p>' +
                              '</div>' +
                              '<p class="note-date" style="color:white;font-size: 20px;">'+$_level+'</p>' +
                              '<div class="d-flex align-items-center">' +
                                  '<span class="mr-3"><i class="fa fa-trash remove-note"></i> Remove</span>' +
                                  '<span class="mr-1"><i class="fa fa-wrench properties-note"></i> Properties</span>' +
                                //   '<div class="ml-auto">' +
                                //         '<div class="category-selector btn-group">' +
                                //                   '<a class="nav-link dropdown-toggle category-dropdown label-group p-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="true">' +
                                //                       '<div class="category">' +
                                //                           '<div class="category-l1"></div>' +
                                //                           '<div class="category-l2"></div>' +
                                //                           '<div class="category-l3"></div>' +
                                //                           '<div class="category-l4"></div>' +
                                //                           '<span class="more-options text-dark"><i class="icon-options-vertical"></i></span>'+
                                //                       '</div>' +
                                //                   '</a>' +
                                //                   '<div class="dropdown-menu dropdown-menu-right category-menu">' +
                                //                       '<a class="level1 badge-group-item badge-business dropdown-item position-relative category-l1" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 1</a>' +
                                //                       '<a class="level2 badge-group-item badge-social dropdown-item position-relative category-l2" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 2</a>' +
                                //                       '<a class="level3 badge-group-item badge-important dropdown-item position-relative category-l3" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 3</a>' +
                                //                       '<a class="level4 badge-group-item badge-important dropdown-item position-relative category-l4" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 4</a>' +
                                //               '</div>' +
                                //        '</div>' +
                                //   '</div>' +
                              '</div>' +
                          '</div></div> ';

      $("#note-full-container").prepend($html);
      $('#addroom').modal('hide');

      removeNote();
      propertiesNote();
      favouriteNote();
      addLabelGroups();
      $(".remove-note, .properties-note").css('cursor', 'pointer');
  });

  // Button add Living
  $("#btn-n-add-lv").on('click', function(event) {
    event.preventDefault();
    var $_level =  $( "#livingLevel" ).val();
    var $_levelLow = $_level.toLowerCase();
    var $_levelTrim = $_levelLow.replace(/\s+/g, '');
    $html =     '<div class="col-md-3 single-note-item all-category '+$_levelTrim+'"><div class="card card-body" style="background-color:#d03a49;">' +
                            '<span class="side-stick"></span>' +
                            '<h4 class="note-title text-truncate w-75 mb-0" data-noteHeading="" style="color:white;"><img src="dist/img/iconsmenu/Living.png" alt="" style="width:3em;"> Living</h4>' +
                            '<div class="note-content" style="display:inline-flex;text-align:center;margin-top: 20px;font-size: 20px">' +
                                '<p style="color:red">RED</p>' +
                                '<p style="margin-left:10px; color:blue;">BLUE</p>' +
                            '</div>' +
                            '<p class="note-date" style="color:white;font-size: 20px;">'+$_level+'</p>' +
                            '<div class="d-flex align-items-center">' +
                                '<span class="mr-3"><i class="fa fa-trash remove-note"></i> Remove</span>' +
                                '<span class="mr-1"><i class="fa fa-wrench properties-note"></i> Properties</span>' +
                                // '<div class="ml-auto">' +
                                //       '<div class="category-selector btn-group">' +
                                //                 '<a class="nav-link dropdown-toggle category-dropdown label-group p-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="true">' +
                                //                     '<div class="category">' +
                                //                         '<div class="category-l1"></div>' +
                                //                         '<div class="category-l2"></div>' +
                                //                         '<div class="category-l3"></div>' +
                                //                         '<div class="category-l4"></div>' +
                                //                         '<span class="more-options text-dark"><i class="icon-options-vertical"></i></span>'+
                                //                     '</div>' +
                                //                 '</a>' +
                                //                 '<div class="dropdown-menu dropdown-menu-right category-menu">' +
                                //                     '<a class="level1 badge-group-item badge-business dropdown-item position-relative category-business" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 1</a>' +
                                //                     '<a class="level2 badge-group-item badge-social dropdown-item position-relative category-social" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 2</a>' +
                                //                     '<a class="level3 badge-group-item badge-important dropdown-item position-relative category-important" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 3</a>' +
                                //                     '<a class="level4 badge-group-item badge-important dropdown-item position-relative category-important" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 4</a>' +
                                //             '</div>' +
                                //      '</div>' +
                                // '</div>' +
                            '</div>' +
                        '</div></div> ';

    $("#note-full-container").prepend($html);
    $('#addliving').modal('hide');

    removeNote();
    propertiesNote();
    favouriteNote();
    addLabelGroups();
    $(".remove-note, .properties-note").css('cursor', 'pointer');
  });

  // Button add Kitchen
  $("#btn-n-add-kit").on('click', function(event) {
    event.preventDefault();
    var $_level =  $( "#kitchenLevel" ).val();
    var $_levelLow = $_level.toLowerCase();
    var $_levelTrim = $_levelLow.replace(/\s+/g, '');
    $html =     '<div class="col-md-3 single-note-item all-category '+$_levelTrim+'"><div class="card card-body" style="background-color:#db5a9a;">' +
                            '<span class="side-stick"></span>' +
                            '<h4 class="note-title text-truncate w-75 mb-0" data-noteHeading="" style="color:white;"><img src="dist/img/iconsmenu/Kitchen.png" alt="" style="width:3em;"> Kitchen</h4>' +
                            '<div class="note-content" style="display:inline-flex;text-align:center;margin-top: 20px;font-size: 20px">' +
                                '<p style="color:red">RED</p>' +
                                '<p style="margin-left:10px; color:blue;">BLUE</p>' +
                            '</div>' +
                            '<p class="note-date" style="color:white;font-size: 20px;">'+$_level+'</p>' +
                            '<div class="d-flex align-items-center">' +
                                '<span class="mr-3"><i class="fa fa-trash remove-note"></i> Remove</span>' +
                                '<span class="mr-1"><i class="fa fa-wrench properties-note"></i> Properties</span>' +
                                // '<div class="ml-auto">' +
                                //       '<div class="category-selector btn-group">' +
                                //                 '<a class="nav-link dropdown-toggle category-dropdown label-group p-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="true">' +
                                //                     '<div class="category">' +
                                //                         '<div class="category-l1"></div>' +
                                //                         '<div class="category-l2"></div>' +
                                //                         '<div class="category-l3"></div>' +
                                //                         '<div class="category-l4"></div>' +
                                //                         '<span class="more-options text-dark"><i class="icon-options-vertical"></i></span>'+
                                //                     '</div>' +
                                //                 '</a>' +
                                //                 '<div class="dropdown-menu dropdown-menu-right category-menu">' +
                                //                     '<a class="level1 badge-group-item badge-business dropdown-item position-relative category-l1" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 1</a>' +
                                //                     '<a class="level2 badge-group-item badge-social dropdown-item position-relative category-l2" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 2</a>' +
                                //                     '<a class="level3 badge-group-item badge-important dropdown-item position-relative category-l3" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 3</a>' +
                                //                     '<a class="level4 badge-group-item badge-important dropdown-item position-relative category-l4" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 4</a>' +
                                //             '</div>' +
                                //     '</div>' +
                                // '</div>' +
                            '</div>' +
                        '</div></div> ';

    $("#note-full-container").prepend($html);
    $('#addkitchen').modal('hide');

    removeNote();
    propertiesNote();
    favouriteNote();
    addLabelGroups();
    $(".remove-note, .properties-note").css('cursor', 'pointer');
  });

  // Button add Bathroom
  $("#btn-n-add-bath").on('click', function(event) {
    event.preventDefault();
    var $_level =  $( "#bathroomLevel" ).val();
    var $_levelLow = $_level.toLowerCase();
    var $_levelTrim = $_levelLow.replace(/\s+/g, '');
    $html =     '<div class="col-md-3 single-note-item all-category '+$_levelTrim+'"><div class="card card-body" style="background-color:#4384cd;">' +
                            '<span class="side-stick"></span>' +
                            '<h4 class="note-title text-truncate w-75 mb-0" data-noteHeading="" style="color:white;"><img src="dist/img/iconsmenu/Bathroom.png" alt="" style="width:3em;"> Bathroom</h4>' +
                            '<div class="note-content" style="display:inline-flex;text-align:center;margin-top: 20px;font-size: 20px">' +
                                '<p style="color:red">RED</p>' +
                                '<p style="margin-left:10px; color:blue;">BLUE</p>' +
                            '</div>' +
                            '<p class="note-date" style="color:white;font-size: 20px;">'+$_level+'</p>' +
                            '<div class="d-flex align-items-center">' +
                                '<span class="mr-3"><i class="fa fa-trash remove-note"></i> Remove</span>' +
                                '<span class="mr-1"><i class="fa fa-wrench properties-note"></i> Properties</span>' +
                                // '<div class="ml-auto">' +
                                //       '<div class="category-selector btn-group">' +
                                //                 '<a class="nav-link dropdown-toggle category-dropdown label-group p-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="true">' +
                                //                     '<div class="category">' +
                                //                         '<div class="category-l1"></div>' +
                                //                         '<div class="category-l2"></div>' +
                                //                         '<div class="category-l3"></div>' +
                                //                         '<div class="category-l4"></div>' +
                                //                         '<span class="more-options text-dark"><i class="icon-options-vertical"></i></span>'+
                                //                     '</div>' +
                                //                 '</a>' +
                                //                 '<div class="dropdown-menu dropdown-menu-right category-menu">' +
                                //                     '<a class="level1 badge-group-item badge-business dropdown-item position-relative category-l1" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 1</a>' +
                                //                     '<a class="level2 badge-group-item badge-social dropdown-item position-relative category-l2" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 2</a>' +
                                //                     '<a class="level3 badge-group-item badge-important dropdown-item position-relative category-l3" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 3</a>' +
                                //                     '<a class="level4 badge-group-item badge-important dropdown-item position-relative category-l4" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 4</a>' +
                                //             '</div>' +
                                //     '</div>' +
                                // '</div>' +
                            '</div>' +
                        '</div></div> ';

    $("#note-full-container").prepend($html);
    $('#addbathroom').modal('hide');

    removeNote();
    propertiesNote();
    favouriteNote();
    addLabelGroups();
    $(".remove-note, .properties-note").css('cursor', 'pointer');
  });

  // Button add Utility Room
  $("#btn-n-add-utr").on('click', function(event) {
    event.preventDefault();
    var $_level =  $( "#utilityLevel" ).val();
    var $_levelLow = $_level.toLowerCase();
    var $_levelTrim = $_levelLow.replace(/\s+/g, '');
    $html =     '<div class="col-md-3 single-note-item all-category '+$_levelTrim+'"><div class="card card-body" style="background-color:#cea94b;">' +
                            '<span class="side-stick"></span>' +
                            '<h4 class="note-title text-truncate w-75 mb-0" data-noteHeading="" style="color:white;"><img src="dist/img/iconsmenu/Utility.png" alt="" style="width:3em;"> Utility Room</h4>' +
                            '<div class="note-content" style="display:inline-flex;text-align:center;margin-top: 20px;font-size: 20px">' +
                                '<p style="color:red">RED</p>' +
                                '<p style="margin-left:10px; color:blue;">BLUE</p>' +
                            '</div>' +
                            '<p class="note-date" style="color:white;font-size: 20px;">'+$_level+'</p>' +
                            '<div class="d-flex align-items-center">' +
                                '<span class="mr-3"><i class="fa fa-trash remove-note"></i> Remove</span>' +
                                '<span class="mr-1"><i class="fa fa-wrench properties-note"></i> Properties</span>' +
                                // '<div class="ml-auto">' +
                                //       '<div class="category-selector btn-group">' +
                                //                 '<a class="nav-link dropdown-toggle category-dropdown label-group p-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="true">' +
                                //                     '<div class="category">' +
                                //                         '<div class="category-l1"></div>' +
                                //                         '<div class="category-l2"></div>' +
                                //                         '<div class="category-l3"></div>' +
                                //                         '<div class="category-l4"></div>' +
                                //                         '<span class="more-options text-dark"><i class="icon-options-vertical"></i></span>'+
                                //                     '</div>' +
                                //                 '</a>' +
                                //                 '<div class="dropdown-menu dropdown-menu-right category-menu">' +
                                //                     '<a class="level1 badge-group-item badge-business dropdown-item position-relative category-l1" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 1</a>' +
                                //                     '<a class="level2 badge-group-item badge-social dropdown-item position-relative category-l2" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 2</a>' +
                                //                     '<a class="level3 badge-group-item badge-important dropdown-item position-relative category-l3" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 3</a>' +
                                //                     '<a class="level4 badge-group-item badge-important dropdown-item position-relative category-l4" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 4</a>' +
                                //             '</div>' +
                                //     '</div>' +
                                // '</div>' +
                            '</div>' +
                        '</div></div> ';

    $("#note-full-container").prepend($html);
    $('#addutilityroom').modal('hide');

    removeNote();
    propertiesNote();
    favouriteNote();
    addLabelGroups();
    $(".remove-note, .properties-note").css('cursor', 'pointer');
  });

  // Button add Laundry Room
  $("#btn-n-add-lar").on('click', function(event) {
    event.preventDefault();
    var $_level =  $( "#laundryLevel" ).val();
    var $_levelLow = $_level.toLowerCase();
    var $_levelTrim = $_levelLow.replace(/\s+/g, '');
    $html =     '<div class="col-md-3 single-note-item all-category '+$_levelTrim+'"><div class="card card-body" style="background-color:#b8a269;">' +
                            '<span class="side-stick"></span>' +
                            '<h4 class="note-title text-truncate w-75 mb-0" data-noteHeading="" style="color:white;"><img src="dist/img/iconsmenu/Laundry.png" alt="" style="width:3em;"> Laundry Room</h4>' +
                            '<div class="note-content" style="display:inline-flex;text-align:center;margin-top: 20px;font-size: 20px">' +
                                '<p style="color:red">RED</p>' +
                                '<p style="margin-left:10px; color:blue;">BLUE</p>' +
                            '</div>' +
                            '<p class="note-date" style="color:white;font-size: 20px;">'+$_level+'</p>' +
                            '<div class="d-flex align-items-center">' +
                                '<span class="mr-3"><i class="fa fa-trash remove-note"></i> Remove</span>' +
                                '<span class="mr-1"><i class="fa fa-wrench properties-note"></i> Properties</span>' +
                                // '<div class="ml-auto">' +
                                //       '<div class="category-selector btn-group">' +
                                //                 '<a class="nav-link dropdown-toggle category-dropdown label-group p-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="true">' +
                                //                     '<div class="category">' +
                                //                         '<div class="category-l1"></div>' +
                                //                         '<div class="category-l2"></div>' +
                                //                         '<div class="category-l3"></div>' +
                                //                         '<div class="category-l4"></div>' +
                                //                         '<span class="more-options text-dark"><i class="icon-options-vertical"></i></span>'+
                                //                     '</div>' +
                                //                 '</a>' +
                                //                 '<div class="dropdown-menu dropdown-menu-right category-menu">' +
                                //                     '<a class="level1 badge-group-item badge-business dropdown-item position-relative category-l1" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 1</a>' +
                                //                     '<a class="level2 badge-group-item badge-social dropdown-item position-relative category-l2" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 2</a>' +
                                //                     '<a class="level3 badge-group-item badge-important dropdown-item position-relative category-l3" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 3</a>' +
                                //                     '<a class="level4 badge-group-item badge-important dropdown-item position-relative category-l4" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Level 4</a>' +
                                //             '</div>' +
                                //     '</div>' +
                                // '</div>' +
                            '</div>' +
                        '</div></div> ';

    $("#note-full-container").prepend($html);
    $('#addlaundryroom').modal('hide');

    removeNote();
    propertiesNote();
    favouriteNote();
    addLabelGroups();
    $(".remove-note, .properties-note").css('cursor', 'pointer');
  });

    $('#addnotesmodal').on('hidden.bs.modal', function (event) {
        event.preventDefault();
    })

    removeNote();
    favouriteNote();
    addLabelGroups();

    // $('#btn-n-add').attr('disabled', 'disabled'); 
})

//  $('#note-has-title').keyup(function() {
//       var empty = false;
//       $('#note-has-title').each(function() {
//           if ($(this).val() == '') {
//                   empty = true;
//           }
//       });

//       if (empty) {
//           $('#btn-n-add').attr('disabled', 'disabled'); 
//       } else {
//           $('#btn-n-add').removeAttr('disabled');
//       }
// });
