
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">PROJECT</h1>
            <h2>Project Name</h2>
          </div><!-- /.col -->
          <div class="col-sm-6">
           
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <div class="page-content container-fluid note-has-grid">
        <ul class="nav nav-pills p-3 bg-white mb-3 rounded-pill align-items-center">
            <li class="nav-item">
                <a href="javascript:void(0)" class="nav-link rounded-pill note-link d-flex align-items-center px-2 px-md-3 mr-0 mr-md-2 active" id="all-category">
                    <i class="icon-layers mr-1"></i><span class="d-none d-md-block">All Rooms</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="javascript:void(0)" class="nav-link rounded-pill note-link d-flex align-items-center px-2 px-md-3 mr-0 mr-md-2" id="level1"> <i class="icon-briefcase mr-1"></i><span class="d-none d-md-block">Level 1</span></a>
            </li>
            <li class="nav-item">
                <a href="javascript:void(0)" class="nav-link rounded-pill note-link d-flex align-items-center px-2 px-md-3 mr-0 mr-md-2" id="level2"> <i class="icon-share-alt mr-1"></i><span class="d-none d-md-block">Level 2</span></a>
            </li>
            <li class="nav-item">
                <a href="javascript:void(0)" class="nav-link rounded-pill note-link d-flex align-items-center px-2 px-md-3 mr-0 mr-md-2" id="level3"> <i class="icon-tag mr-1"></i><span class="d-none d-md-block">Level 3</span></a>
            </li>
            <li class="nav-item">
                <a href="javascript:void(0)" class="nav-link rounded-pill note-link d-flex align-items-center px-2 px-md-3 mr-0 mr-md-2" id="level4"> <i class="icon-tag mr-1"></i><span class="d-none d-md-block">Level 4</span></a>
            </li>
        </ul>
        <div class="tab-content bg-transparent">
            <div id="note-full-container" class="note-has-grid row">
            </div>
        </div>

        <!-- Modal Add Master Bedroom -->
        <div class="modal fade" id="addmasterbedroom" tabindex="-1" role="dialog" aria-labelledby="addnotesmodalTitle" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content border-0">
                    <div class="modal-header text-white" style="background-color: #f3745c;">
                        <h5 class="modal-title text-white">Add Master Bedroom</h5>
                        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="notes-box">
                            <div class="notes-content">
                                <form action="javascript:void(0);" id="addnotesmodalTitle">
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <div class="note-title">
                                                <label>Select a level</label>
                                                <!-- <input type="text" id="note-has-title" class="form-control" minlength="25" placeholder="Title" /> -->
                                                <select class="form-control" id="mbLevel">
                                                    <option>Level 1</option>
                                                    <option>Level 2</option>
                                                    <option>Level 3</option>
                                                    <option>Level 4</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- <div class="col-md-12">
                                            <div class="note-description">
                                                <label>Note Description</label>
                                                <textarea id="note-has-description" class="form-control" minlength="60" placeholder="Description" rows="3"></textarea>
                                            </div>
                                        </div> -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-danger" data-dismiss="modal">Discard</button>
                        <button id="btn-n-add-mb" class="btn btn-success">Add</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Model Add Room -->
        <div class="modal fade" id="addroom" tabindex="-1" role="dialog" aria-labelledby="addnotesmodalTitle" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content border-0">
                    <div class="modal-header text-white" style="background-color: #f3745c;">
                        <h5 class="modal-title text-white">Add Room</h5>
                        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="notes-box">
                            <div class="notes-content">
                                <form action="javascript:void(0);" id="addnotesmodalTitle">
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <div class="note-title">
                                                <label>Select a level</label>
                                                <!-- <input type="text" id="note-has-title" class="form-control" minlength="25" placeholder="Title" /> -->
                                                <select class="form-control" id="roomLevel">
                                                    <option>Level 1</option>
                                                    <option>Level 2</option>
                                                    <option>Level 3</option>
                                                    <option>Level 4</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- <div class="col-md-12">
                                            <div class="note-description">
                                                <label>Note Description</label>
                                                <textarea id="note-has-description" class="form-control" minlength="60" placeholder="Description" rows="3"></textarea>
                                            </div>
                                        </div> -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="btn-n-save" class="float-left btn btn-success" style="display: none;">Save</button>
                        <button class="btn btn-danger" data-dismiss="modal">Discard</button>
                        <button id="btn-n-add-ro" class="btn btn-success">Add</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Model Add Living -->
        <div class="modal fade" id="addliving" tabindex="-1" role="dialog" aria-labelledby="addnotesmodalTitle" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content border-0">
                    <div class="modal-header text-white" style="background-color: #ed5d6b;">
                        <h5 class="modal-title text-white">Add Living</h5>
                        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="notes-box">
                            <div class="notes-content">
                                <form action="javascript:void(0);" id="addnotesmodalTitle">
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <div class="note-title">
                                                <label>Select a level</label>
                                                <!-- <input type="text" id="note-has-title" class="form-control" minlength="25" placeholder="Title" /> -->
                                                <select class="form-control" id="livingLevel">
                                                    <option>Level 1</option>
                                                    <option>Level 2</option>
                                                    <option>Level 3</option>
                                                    <option>Level 4</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- <div class="col-md-12">
                                            <div class="note-description">
                                                <label>Note Description</label>
                                                <textarea id="note-has-description" class="form-control" minlength="60" placeholder="Description" rows="3"></textarea>
                                            </div>
                                        </div> -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="btn-n-save" class="float-left btn btn-success" style="display: none;">Save</button>
                        <button class="btn btn-danger" data-dismiss="modal">Discard</button>
                        <button id="btn-n-add-lv" class="btn btn-success">Add</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Model Add Kitchen -->
        <div class="modal fade" id="addkitchen" tabindex="-1" role="dialog" aria-labelledby="addnotesmodalTitle" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content border-0">
                    <div class="modal-header text-white" style="background-color: #e88cba;">
                        <h5 class="modal-title text-white">Add Kitchen</h5>
                        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="notes-box">
                            <div class="notes-content">
                                <form action="javascript:void(0);" id="addnotesmodalTitle">
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <div class="note-title">
                                                <label>Select a level</label>
                                                <!-- <input type="text" id="note-has-title" class="form-control" minlength="25" placeholder="Title" /> -->
                                                <select class="form-control" id="kitchenLevel">
                                                    <option>Level 1</option>
                                                    <option>Level 2</option>
                                                    <option>Level 3</option>
                                                    <option>Level 4</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- <div class="col-md-12">
                                            <div class="note-description">
                                                <label>Note Description</label>
                                                <textarea id="note-has-description" class="form-control" minlength="60" placeholder="Description" rows="3"></textarea>
                                            </div>
                                        </div> -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="btn-n-save" class="float-left btn btn-success" style="display: none;">Save</button>
                        <button class="btn btn-danger" data-dismiss="modal">Discard</button>
                        <button id="btn-n-add-kit" class="btn btn-success">Add</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Model Add Bathroom -->
        <div class="modal fade" id="addbathroom" tabindex="-1" role="dialog" aria-labelledby="addnotesmodalTitle" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content border-0">
                    <div class="modal-header text-white" style="background-color: #6c9cd2;">
                        <h5 class="modal-title text-white">Add Bathroom</h5>
                        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="notes-box">
                            <div class="notes-content">
                                <form action="javascript:void(0);" id="addnotesmodalTitle">
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <div class="note-title">
                                                <label>Select a level</label>
                                                <!-- <input type="text" id="note-has-title" class="form-control" minlength="25" placeholder="Title" /> -->
                                                <select class="form-control" id="bathroomLevel">
                                                    <option>Level 1</option>
                                                    <option>Level 2</option>
                                                    <option>Level 3</option>
                                                    <option>Level 4</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- <div class="col-md-12">
                                            <div class="note-description">
                                                <label>Note Description</label>
                                                <textarea id="note-has-description" class="form-control" minlength="60" placeholder="Description" rows="3"></textarea>
                                            </div>
                                        </div> -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="btn-n-save" class="float-left btn btn-success" style="display: none;">Save</button>
                        <button class="btn btn-danger" data-dismiss="modal">Discard</button>
                        <button id="btn-n-add-bath" class="btn btn-success">Add</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Model Add Utility Room -->
        <div class="modal fade" id="addutilityroom" tabindex="-1" role="dialog" aria-labelledby="addnotesmodalTitle" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content border-0">
                    <div class="modal-header text-white" style="background-color: #dbc180;">
                        <h5 class="modal-title text-white">Add Utility Room</h5>
                        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="notes-box">
                            <div class="notes-content">
                                <form action="javascript:void(0);" id="addnotesmodalTitle">
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <div class="note-title">
                                                <label>Select a level</label>
                                                <!-- <input type="text" id="note-has-title" class="form-control" minlength="25" placeholder="Title" /> -->
                                                <select class="form-control" id="utilityLevel">
                                                    <option>Level 1</option>
                                                    <option>Level 2</option>
                                                    <option>Level 3</option>
                                                    <option>Level 4</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- <div class="col-md-12">
                                            <div class="note-description">
                                                <label>Note Description</label>
                                                <textarea id="note-has-description" class="form-control" minlength="60" placeholder="Description" rows="3"></textarea>
                                            </div>
                                        </div> -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="btn-n-save" class="float-left btn btn-success" style="display: none;">Save</button>
                        <button class="btn btn-danger" data-dismiss="modal">Discard</button>
                        <button id="btn-n-add-utr" class="btn btn-success">Add</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Model Add Laundry Room -->
        <div class="modal fade" id="addlaundryroom" tabindex="-1" role="dialog" aria-labelledby="addnotesmodalTitle" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content border-0">
                    <div class="modal-header text-white" style="background-color: #b8a269;">
                        <h5 class="modal-title text-white">Add Laundry Room</h5>
                        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="notes-box">
                            <div class="notes-content">
                                <form action="javascript:void(0);" id="addnotesmodalTitle">
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <div class="note-title">
                                                <label>Select a level</label>
                                                <!-- <input type="text" id="note-has-title" class="form-control" minlength="25" placeholder="Title" /> -->
                                                <select class="form-control" id="laundryLevel">
                                                    <option>Level 1</option>
                                                    <option>Level 2</option>
                                                    <option>Level 3</option>
                                                    <option>Level 4</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- <div class="col-md-12">
                                            <div class="note-description">
                                                <label>Note Description</label>
                                                <textarea id="note-has-description" class="form-control" minlength="60" placeholder="Description" rows="3"></textarea>
                                            </div>
                                        </div> -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="btn-n-save" class="float-left btn btn-success" style="display: none;">Save</button>
                        <button class="btn btn-danger" data-dismiss="modal">Discard</button>
                        <button id="btn-n-add-lar" class="btn btn-success">Add</button>
                    </div>
                </div>
            </div>
        </div>


    </div>


    <div class="modal fade" id="modal-properties" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <div id="modal-icon"></div>
                    <h5 class="modal-title ml-2 text-white">Properties <span class="text-white-50 ml-2" id="room-level"></span></h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div id="properties-general">

                        <div class="row">
                            <div class="col-12 col-md-4">
                                <div class="form-group">
                                    <label for="inputProject">Actual name</label>
                                    <input type="text" id="actualName" class="form-control">
                                </div>
                            </div>

                            <div class="col-12 col-md-4 level-1">
                                <div class="d-flex flex-column justify-content-center h-100">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="isBasement" id="isBasement" checked>
                                        <label class="form-check-label">Basement</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="isBasement">
                                        <label class="form-check-label" for="exampleRadios2">Slab On Grade</label>
                                    </div>
                                </div>
                            </div>

                            <div class="col d-flex flex-column justify-content-center">
                                    <div class="custom-control custom-switch no-level-1">
                                        <input type="checkbox" class="custom-control-input" id="isSlabOnGrade">
                                        <label class="custom-control-label" for="isSlabOnGrade">Slab On Grade</label>
                                    </div>
                                    <div class="custom-control custom-switch level-1">
                                        <input type="checkbox" class="custom-control-input" id="isBasementExisting">
                                        <label class="custom-control-label" for="isBasementExisting">Basement existing</label>
                                    </div>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="isExistingAirLeakage">
                                        <label class="custom-control-label" for="isExistingAirLeakage">Existing Air Leakage</label>
                                    </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12 col-md-6 col-lg-4">
                                <div class="form-group">
                                    <label for="inputProject">Height</label>
                                    <input type="text" id="height" class="form-control">
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-lg-4">
                                <div class="form-group">
                                    <label for="inputProject">Above grade</label>
                                    <input type="text" id="aboveGrade" class="form-control" disabled>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-lg-4">
                                <div class="form-group">
                                    <label for="inputProject">Below grade</label>
                                    <input type="text" id="belowGrade" class="form-control" disabled>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div id="properties-components">
                        <h5>Components</h5>

                        <div class="border rounded overflow-auto horizontal-scroll">
                            <div class="horizontal-components">
                                <div class="p-0">
                                    <table class="table w-100 table-bordered m-0 properties-table"><tbody>
                                        <tr>
                                            <td class="component-cell"></td>
                                            <td class="measurement-cell">Measurement</td>
                                            <td class="hl-cell">
                                                <div class="input-group input-group-sm">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text">HL</span>
                                                    </div>
                                                    <input id="hl" type="text" class="form-control" value="0" disabled>
                                                </div>
                                            </td>
                                            <td class="hg-cell">
                                                <div class="input-group input-group-sm">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text">HG</span>
                                                    </div>
                                                    <input id="hg" type="text" class="form-control" value="0" disabled>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </div>
                            </div>
                            <div class="col overflow-auto p-0 vertical-container vertical-scroll" id="components-container"></div>
                        </div>
                        
                        <div class="d-none" id="component-template">
                            <table class="table w-100 table-bordered m-0 properties-table"><tbody>
                                <tr>
                                    <td class="component-cell"></td>
                                    <td class="measurement-cell">
                                        <div class="input-group input-group-sm">
                                                <input type="number" min="0" class="form-control measurement" placeholder="Measurement">
                                        </div>
                                    </td>
                                    <td class="hl-cell">
                                        <div class="input-group input-group-sm">
                                            <input type="text" class="form-control hl" value="0" disabled>
                                        </div>
                                    </td>
                                    <td class="hg-cell">
                                        <div class="input-group input-group-sm">
                                            <input type="text" class="form-control hg" value="0" disabled>
                                        </div>
                                    </td>
                                </tr>
                            </tbody></table>
                        </div>

                        <div class="d-none" id="component-system">
                            <table class="table w-100 table-bordered m-0 properties-table"><tbody>
                                <tr>
                                    <td>System</td>
                                    <td class="system-cell">
                                        <select class="form-control form-control-sm system">
                                            <option>System A</option>
                                        </select>
                                    </td>
                                    <td class="vent-case-cell">
                                        <div class="input-group input-group-sm">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Vent. Case 2 Only</span>
                                                </div>
                                            <input type="text" class="form-control hg" value="0" disabled>
                                        </div>
                                    </td>
                                </tr>
                            </tbody></table>
                        </div>
                    </div>

                    <div class="mt-3" id="properties-r-values">
                        <h5>Local R-Values</h5>

                        <div class="border rounded overflow-auto horizontal-scroll">
                            <div class="horizontal-r-values">
                                <div class="p-0">
                                    <table class="table w-100 table-bordered m-0 r-values-table"><tbody>
                                        <tr>
                                            <td class="r-value-name-cell"></td>
                                            <td class="is-package-values-cell text-break">Use package values</td>
                                            <td class="r-value-cell">R-Value</td>
                                            <td class="rsi-cell">RSI</td>
                                            <td class="eff-r-value-cell">Eff. R-Value</td>
                                            <td class="heatloss-cell">Heatloss</td>
                                            <td class="heatgain-cell">Heatgain</td>
                                            <td class="ex-eff-r-value-cell">Ex.Eff. R-Value</td>
                                            <td class="ex-measurement-cell">Ex. measure.</td>
                                            <td class="ex-heatloss-cell">Ex. Heatloss</td>
                                            <td class="ex-heatgain-cell">Ex. Heatgain</td>
                                        </tr>
                                    </tbody></table>
                                </div>
                            </div>
                            <div class="col overflow-auto p-0 vertical-container vertical-scroll" id="r-values-container"></div>
                        </div>
                        
                        <div class="d-none" id="r-value-template">
                            <table class="table w-100 table-bordered m-0 r-values-table"><tbody>
                                <tr>
                                    <td class="r-value-name-cell"></td>
                                    <td class="is-package-values-cell">
                                        <div class="form-check">
                                            <input class="form-check-input position-static is-package-value" type="checkbox" checked>
                                        </div>
                                    </td>
                                    <td class="r-value-cell">
                                        <div class="input-group input-group-sm">
                                                <input type="text" class="form-control r-value" value="0" disabled>
                                        </div>
                                    </td>
                                    <td class="rsi-cell">
                                        <div class="input-group input-group-sm">
                                                <input type="text" class="form-control rsi" value="0" disabled>
                                        </div>
                                    </td>
                                    <td class="eff-r-value-cell">
                                        <div class="input-group input-group-sm">
                                                <input type="text" class="form-control eff-r-value" value="0" disabled>
                                        </div>
                                    </td>
                                    <td class="heatloss-cell">
                                        <div class="input-group input-group-sm">
                                                <input type="text" class="form-control heatloss" value="0" disabled>
                                        </div>
                                    </td>
                                    <td class="heatgain-cell">
                                        <div class="input-group input-group-sm">
                                                <input type="text" class="form-control heatgain" value="0" disabled>
                                        </div>
                                    </td>
                                    <td class="ex-eff-r-value-cell">
                                        <div class="input-group input-group-sm">
                                                <input type="text" class="form-control ex-eff-r-value" value="0" disabled>
                                        </div>
                                    </td>
                                    <td class="ex-measurement-cell">
                                        <div class="input-group input-group-sm">
                                                <input type="text" class="form-control ex-measurement" value="0" disabled>
                                        </div>
                                    </td>
                                    <td class="ex-heatloss-cell">
                                        <div class="input-group input-group-sm">
                                                <input type="text" class="form-control ex-heatloss" value="0" disabled>
                                        </div>
                                    </td>
                                    <td class="ex-heatgain-cell">
                                        <div class="input-group input-group-sm">
                                                <input type="text" class="form-control ex-heatgain" value="0" disabled>
                                        </div>
                                    </td>
                                </tr>
                            </tbody></table>
                        </div>

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Discard changes</button>
                    <button type="button" class="btn btn-success">Save changes</button>
                </div>
            </div>
        </div>
    </div>

    </section>


    <!-- ALERTIFY -->
<!-- JavaScript -->
<script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

<!-- CSS -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
<!-- Default theme -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/default.min.css"/>
<!-- Semantic UI theme -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/semantic.min.css"/>
<!-- Bootstrap theme -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/bootstrap.min.css"/>

<!-- LEVEL CARD JS -->
<script src="dist/js/levelCard.js"></script>

<!-- room properties -->
<script src="dist/js/room-properties.js"></script>
<link rel="stylesheet" href="dist/css/room-properties.css">
