    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">SYSTEMS CONFIG</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
           
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->


    <section class="content">
        <div class="row">
            <!-- SUPPLIES -->
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header" style="background-color: #076d06;">
                        <h3 class="card-title">SUPPLIES</h3>
                    
                    <!-- <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                        <i class="fas fa-plus"></i>
                        </button>
                    </div> -->
                </div>
                <div class="card-body">
                    <div class="row">
                        <!-- LEVEL 4 -->
                        <div class="col-md-12">
                            <div class="card card-primary">
                                <div class="card-header" style="background-color: #05052f;">
                                    <h3 class="card-title">LEVEL 4</h3>
                                <!-- PREGUNTAR SI SE QUIERE COLAPSADA LA CARD -->
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                    <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <!-- CARD GENERIC -->
                                    <div class="col-md-12">
                                        <div class="card card-primary">
                                            <div class="card-header" style="background-color: #05052f;">
                                            <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                    <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                                            <div class="row align-items-center">
                                                <div class="col-sm-3">
                                                    <h3 class="card-title">Master</h3>
                                                </div>
                                                <div class="col-sm-3">
                                                    <h5>H.L = 4879</h5>
                                                </div>
                                                <div class="col-sm-3">
                                                    <h5>H.G = 7058</h5>
                                                </div>
                                                <div class="col-sm-3">
                                                    <div class="form-group m-0">
                                                        <select class="form-control-sm w-75">
                                                        <option>A</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                                
                                                
                                                
                                        </div>

                                        <div class="supplies" data-btuhh="1191" data-btuhc="1190" data-cfmh="0" data-cfmc="0"></div>

                                    </div>
                                    <!-- /.card -->
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                        </div>
                    </div>
                    <div class="row">
                        <!-- LEVEL 3-->
                        <div class="col-md-12">
                            <div class="card card-primary">
                                <div class="card-header" style="background-color:#131449;">
                                    <h3 class="card-title">LEVEL 3</h3>
                                
                                <!-- <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                    <i class="fas fa-plus"></i>
                                    </button>
                                </div> -->
                            </div>
                            <div class="card-body">
                                
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                        </div>
                    </div>
                    <div class="row">
                        <!-- LEVEL 2 -->
                        <div class="col-md-12">
                            <div class="card card-primary">
                                <div class="card-header" style="background-color:#2b2c69;">
                                    <h3 class="card-title">LEVEL 2</h3>
                                
                                <!-- <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                    <i class="fas fa-plus"></i>
                                    </button>
                                </div> -->
                            </div>
                            <div class="card-body">
                                
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                        </div>
                    </div>
                    <div class="row">
                        <!-- LEVEL 1-->
                        <div class="col-md-12">
                            <div class="card card-primary">
                                <div class="card-header" style="background-color: #505293;">
                                    <h3 class="card-title">LEVEL 1</h3>
                                
                                <!-- <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                    <i class="fas fa-plus"></i>
                                    </button>
                                </div> -->
                            </div>
                            <div class="card-body">
                                
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
            </div>
        </div>
        <div class="row">
            <!-- RETURNS -->
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header" style="background-color: #6d0606;">
                        <h3 class="card-title">RETURNS</h3>
                    <!-- <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                        <i class="fas fa-plus"></i>
                        </button>
                    </div> -->
                </div>
                <div class="card-body entries">

                    <div class="entry-template d-none" style="width: 150px;min-width: 150px;">
                        <table class="table table-striped border table-supplies"><tbody>
                            <tr><td><input class="form-control form-control-sm inlet" type="text" placeholder="Inlet #"></td></tr>
                            <tr><td><input class="form-control form-control-sm cfm" type="number" min="0" step="2" placeholder=" Air Volume"></td></tr>
                            <tr><td><input class="form-control form-control-sm a-lenght actualiza-t-lenght" type="number" pattern="\d*" min="0" step="2" placeholder="A. Lenght"></td></tr>
                            <tr><td><input class="form-control form-control-sm e-lenght actualiza-t-lenght" type="number" pattern="\d*" min="0" step="2" placeholder="E. Lenght"></td></tr>
                            <tr><td><input class="form-control-plaintext form-control-sm t-lenght" type="text" value="0" readonly></td></tr>
                            <tr><td><input class="form-control-plaintext form-control-sm a-press" type="text" value="-" readonly></td></tr>
                            <tr><td><input class="form-control form-control-sm pipe-size" type="text" placeholder="Pipe Size"></td></tr>
                            <tr><td><input class="form-control form-control-sm inlet-size" type="text" placeholder="Inlet Size" value="14x8"></td></tr>
                            <tr><td><input class="form-control form-control-sm return-trunk" type="text" placeholder="Return trunk"></td></tr>
                            <tr><td><select class="form-control form-control-sm system"><option>System A</option></select></td></tr>
                            <tr><td><button type="button" class="btn btn-outline-danger btn-block btn-sm remove-inlet">Remove</button></td></tr>
                        </tbody></table>
                    </div>

                    <div class="row align-items-center">
                        <div class="col-12 col-md-6 mb-3">
                            <h4 class="m-0">Return branch and grill sizing</h4>
                        </div>
                        <div class="col mb-3">
                            <div class="d-flex flex-row justify-content-end">
                                <button type="button" class="btn btn-secondary mr-1 scroll-btn-left" disabled><i class="fas fa-angle-left"></i></button>
                                <button type="button" class="btn btn-secondary mr-3 scroll-btn-right" disabled><i class="fas fa-angle-right"></i></button>
                                <button type="button" class="btn btn-primary add-entry">Add inlet</button>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="row border rounded">

                        <div class="border-right p-0">
                            <table class="table table-striped table-supplies-header"><tbody>
                                <tr><td>Inlet #</td></tr>
                                <tr><td><span class="d-none d-lg-block">Inlet Air Volume CFM</span><span class="d-lg-none">Air Volume</span></td></tr>
                                <tr><td>A. Lenght</td></tr>
                                <tr><td>E. Lenght</td></tr>
                                <tr><td>T. Lenght</td></tr>
                                <tr><td>A. Pressure</td></tr>
                                <tr><td>Pipe Size</td></tr>
                                <tr><td>Inlet size</td></tr>
                                <tr><td>Return Trunk</td></tr>
                                <tr><td>System</td></tr>
                                <tr><td></td></tr>
                            </tbody></table>
                        </div>

                        <div class="col entries-container horizontal-scroll d-flex flex-nowrap overflow-auto p-0"></div>

                    </div>
                    
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
            </div>
        </div>
        <div class="row">
            <!-- TRUNK DUCT SIZING -->
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header" style="background-color: #cba105;">
                        <h3 class="card-title">TRUNK DUCT SIZING</h3>
                    <!-- <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                        <i class="fas fa-plus"></i>
                        </button>
                    </div> -->
                </div>
                
                <div class="card-body entries">
                    
                    <div class="entry-template d-none">
                        <table class="table w-100 table-bordered table-hover m-0"><tbody>
                            <tr>
                                <td class="trunk-cell"><input class="form-control form-control-sm trunk" type="text" placeholder="Trunk"></td>
                                <td class="cfm-cell"><input class="form-control-plaintext form-control-sm cfm" type="text" value="0" readonly></td>
                                <td class="connect-cell"><input class="form-control form-control-sm connect" type="text" placeholder="Connect"></td>
                                <td class="press-cell"><input class="form-control-plaintext form-control-sm press" type="text" value="0" readonly></td>
                                <td class="round-cell"><input class="form-control-plaintext form-control-sm round" type="text" value="0" readonly></td>
                                <td class="rect-cell"><input class="form-control form-control-sm rect-size" type="text" placeholder="Rect. Size"></td>
                                <td class="alternate-cell"><input class="form-control form-control-sm alternate-size" type="text" placeholder="Alternate Size"></td>
                                <td class="system-cell"><select class="form-control form-control-sm system"><option>System A</option></select></td>
                                <td class="remove-cell"><button type="button" class="btn btn-outline-danger btn-block btn-sm remove-trunk">Remove</button></td>
                            </tr>
                        </tbody></table>
                    </div>

                    <div class="row align-items-center">
                        <div class="col-12 col-md-6 mb-3">
                            <h4 class="m-0">Return trunk duct sizing</h4>
                        </div>
                        <div class="col mb-3">
                            <div class="d-flex flex-row justify-content-end">
                                <button type="button" class="btn btn-secondary mr-1 scroll-btn-left" disabled><i class="fas fa-angle-left"></i></button>
                                <button type="button" class="btn btn-secondary mr-3 scroll-btn-right" disabled><i class="fas fa-angle-right"></i></button>
                                <button type="button" class="btn btn-secondary mr-1 scroll-btn-up" disabled><i class="fas fa-angle-up"></i></button>
                                <button type="button" class="btn btn-secondary mr-3 scroll-btn-down" disabled><i class="fas fa-angle-down"></i></button>
                                <button type="button" class="btn btn-primary add-entry">Add <span class="d-none d-sm-inline">return </span>trunk</button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="border rounded overflow-auto horizontal-scroll">
                        <div class="horizontal-entries">

                            <div class="p-0">
                                <table class="table w-100 table-bordered m-0"><tbody>
                                    <tr>
                                        <td class="trunk-cell">Trunk</td>
                                        <td class="cfm-cell">CFM</td>
                                        <td class="connect-cell">Connect</td>
                                        <td class="press-cell">Press.</td>
                                        <td class="round-cell">Round</td>
                                        <td class="rect-cell">Rect. Size</td>
                                        <td class="alternate-cell">Alternate Size</td>
                                        <td class="system-cell">System</td>
                                        <td class="remove-cell"></td>
                                    </tr>
                                </tbody></table>
                            </div>

                            <div class="col entries-container overflow-auto p-0 vertical-container vertical-scroll"></div>

                        </div>
                    </div>

                </div>
                
                <div class="card-body entries">
                    
                    <div class="entry-template d-none">
                        <table class="table w-100 table-bordered table-hover m-0"><tbody>
                            <tr>
                                <td class="trunk-cell"><input class="form-control form-control-sm trunk" type="text" placeholder="Trunk"></td>
                                <td class="cfm-cell"><input class="form-control-plaintext form-control-sm cfm" type="text" value="0" readonly></td>
                                <td class="connect-cell"><input class="form-control form-control-sm connect" type="text" placeholder="Connect"></td>
                                <td class="press-cell"><input class="form-control-plaintext form-control-sm press" type="text" value="0" readonly></td>
                                <td class="round-cell"><input class="form-control-plaintext form-control-sm round" type="text" value="0" readonly></td>
                                <td class="rect-cell"><input class="form-control form-control-sm rect-size" type="text" placeholder="Rect. Size"></td>
                                <td class="alternate-cell"><input class="form-control form-control-sm alternate-size" type="text" placeholder="Alternate Size"></td>
                                <td class="system-cell"><select class="form-control form-control-sm system"><option>System A</option></select></td>
                                <td class="remove-cell"><button type="button" class="btn btn-outline-danger btn-block btn-sm remove-trunk">Remove</button></td>
                            </tr>
                        </tbody></table>
                    </div>

                    <div class="row align-items-center">
                        <div class="col-12 col-md-6 mb-3">
                            <h4 class="m-0">Supply trunk duct sizing</h4>
                        </div>
                        <div class="col mb-3">
                            <div class="d-flex flex-row justify-content-end">
                                <button type="button" class="btn btn-secondary mr-1 scroll-btn-left" disabled><i class="fas fa-angle-left"></i></button>
                                <button type="button" class="btn btn-secondary mr-3 scroll-btn-right" disabled><i class="fas fa-angle-right"></i></button>
                                <button type="button" class="btn btn-secondary mr-1 scroll-btn-up" disabled><i class="fas fa-angle-up"></i></button>
                                <button type="button" class="btn btn-secondary mr-3 scroll-btn-down" disabled><i class="fas fa-angle-down"></i></button>
                                <button type="button" class="btn btn-primary add-entry">Add <span class="d-none d-sm-inline">supply </span>trunk</button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="border rounded overflow-auto horizontal-scroll">
                        <div class="horizontal-entries">

                            <div class="p-0">
                                <table class="table w-100 table-bordered m-0"><tbody>
                                    <tr>
                                        <td class="trunk-cell">Trunk</td>
                                        <td class="cfm-cell">CFM</td>
                                        <td class="connect-cell">Connect</td>
                                        <td class="press-cell">Press.</td>
                                        <td class="round-cell">Round</td>
                                        <td class="rect-cell">Rect. Size</td>
                                        <td class="alternate-cell">Alternate Size</td>
                                        <td class="system-cell">System</td>
                                        <td class="remove-cell"></td>
                                    </tr>
                                </tbody></table>
                            </div>

                            <div class="col entries-container overflow-auto p-0 vertical-container vertical-scroll"></div>

                        </div>
                    </div>

                </div>
                
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
            </div>
        </div>
        <div class="row" style="justify-content: center;">
            <a class="btn btn-success" href="dashboard.php?action=projects" style="width: 100%;">Save</a>
            <a href="dashboard.php?action=projects" class="btn btn-secondary" style="width: 100%;">Cancel</a>
                <!-- <input type="submit" value="Next" class="btn btn-success float-right"> -->
        </div>

        <div class="card-body entries supplies-template d-none">

            <div class="entry-template d-none" style="width: 150px;min-width: 150px;">
                <table class="table table-striped border table-supplies"><tbody>
                    <tr><td><input class="form-control form-control-sm supply" type="text" placeholder="Supply #"></td></tr>
                    <tr><td><input class="form-control-plaintext form-control-sm btuhh" type="text" value="" readonly></td></tr>
                    <tr><td><input class="form-control-plaintext form-control-sm btuhc" type="text" value="" readonly></td></tr>
                    <tr><td><input class="form-control-plaintext form-control-sm cfmh" type="text" value="" readonly></td></tr>
                    <tr><td><input class="form-control-plaintext form-control-sm cfmc" type="text" value="" readonly></td></tr>
                    <tr><td><input class="form-control form-control-sm e-lenght actualiza-t-lenght" type="number" pattern="\d*" min="0" step="2" placeholder="E. Lenght"></td></tr>
                    <tr><td><input class="form-control form-control-sm a-lenght actualiza-t-lenght" type="number" pattern="\d*" min="0" step="2" placeholder="A. Lenght"></td></tr>
                    <tr><td><input class="form-control-plaintext form-control-sm t-lenght" type="text" value="0" readonly></td></tr>
                    <tr><td><input class="form-control-plaintext form-control-sm a-press" type="text" value="-" readonly></td></tr>
                    <tr><td><input class="form-control form-control-sm pipe-size" type="text" placeholder="Pipe Size" value="5"></td></tr>
                    <tr><td><input class="form-control form-control-sm trunk" type="text" placeholder="Trunk"></td></tr>
                    <tr><td><button type="button" class="btn btn-outline-danger btn-block btn-sm remove-supply">Remove</button></td></tr>
                </tbody></table>
            </div>

            <div class="d-flex flex-row justify-content-end mb-3">
                <button type="button" class="btn btn-secondary mr-1 scroll-btn-left" disabled><i class="fas fa-angle-left"></i></button>
                <button type="button" class="btn btn-secondary mr-3 scroll-btn-right" disabled><i class="fas fa-angle-right"></i></button>
                <button type="button" class="btn btn-primary add-entry">Add supply</button>
            </div>
            
            <div class="row border rounded">

                <div class="border-right p-0">
                    <table class="table table-striped table-supplies-header"><tbody>
                        <tr><td>Supply #</td></tr>
                        <tr><td>BTUHH</td></tr>
                        <tr><td>BTUHC</td></tr>
                        <tr><td>CFMH</td></tr>
                        <tr><td>CFMC</td></tr>
                        <tr><td>E. Lenght</td></tr>
                        <tr><td>A. Lenght</td></tr>
                        <tr><td>T. Lenght</td></tr>
                        <tr><td>A. Press.</td></tr>
                        <tr><td>Pipe Size</td></tr>
                        <tr><td>Trunk</td></tr>
                        <tr><td></td></tr>
                    </tbody></table>
                </div>

                <div class="col entries-container horizontal-scroll d-flex flex-nowrap overflow-auto p-0"></div>

            </div>

        </div>
    </section>